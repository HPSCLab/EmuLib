# -*- coding:utf-8 -*-
__Developer__ = 'Ssong'
__Version__ = '1.0V'

try:
    import os, sys, time, base64, subprocess, datetime, platform
    import urllib, urllib2, cookielib, ssl
    import mechanize, BeautifulSoup
    import hashlib, json, inspect
    from Crypto.Cipher import AES
except:
    print 'Module Importing Fail'
    exit(1)

class SingleLib():
    def __init__(self):
        self.cj = cookielib.CookieJar()
        self.context = ssl.SSLContext(ssl.PROTOCOL_TLSv1)
        self.opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cj), urllib2.HTTPSHandler(context=self.context))
        self.__Encryption()
        self.sessiondata = dict()
        self.proj, self.reboot, self.report, self.filedump, \
        self.registrydump, self.trafficdump, self.uploaded_filepath = None,  None,  None,  None,  None,  None,  None

    def __Encryption(self): #암호화 모듈
        BLOCK_SIZE = 32
        PADDING = '|'
        secret = 'XJjOXNHY2lya2lZZTdkVzE0RU54L0Fwc'
        cipher = AES.new(secret)

        pad = lambda s : s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
        self.EncryptionAES = lambda s : base64.b64encode(cipher.encrypt(pad(s)))
        self.DecryptionAES = lambda e : cipher.decrypt(base64.b64decode(e)).rstrip(PADDING)

    def Analysis_setting(self, proj, reboot, report, filedump, registrydump, trafficdump, filepath):
        if filedump == 'No' and registrydump == 'No' and trafficdump == 'No':
            print 'Analysis options must be selected more than a one'
            exit(1)
        # A logic of bottom checks the whether a file and extract the name and extension of a file.
        if os.path.isfile(filepath): # must have to check whether is file or nor.
            fp_exetension = os.path.splitext(os.path.basename(filepath))
            fp_name = fp_exetension[0]+fp_exetension[1]
            fp_exetension = fp_exetension[1].lower()

            if fp_exetension == '.exe' or fp_exetension == '.exec': # must have to check the file's extension.
                pass
            else:
                print 'Error:We only support a file extension of "*.exe" or "*.exec" format and a file'+"'s extension must be written behind the filename which you wanna upload."
                exit(1) # Checking logic end.
        else:
            print 'Error:Only an execution file is possible to upload.'
            exit(1) # File checking logic end.

        # Variable's value checking logic
        frame = inspect.getargvalues(inspect.currentframe())
        for j in range(2, 7):
            if frame[3][frame[0][j]] is not 'Yes' and frame[3][frame[0][j]] is not 'No':
                print 'Please give a "%s" argument the value which is only "Yes" or "No".' % frame[0][j]
                exit(1)
            else:
                pass
        # End

        self.proj, self.reboot, self.report, self.filedump = proj, reboot, report, filedump
        self.registrydump, self.trafficdump, self.filepath = registrydump, trafficdump, filepath


    def __connecting(self):
        url = 'https://www.emulab.kreonet.net/'
        try:
            ConnectingConfrim = self.opener.open(url).read()
        except:
            return {'Result':'Fail'}
        else:
            return {'Result':'Success'}

    def __login(self, id ,pw):
        connecting_check = self.__connecting()
        infodic = dict()
        if connecting_check['Result'] == 'Fail':
            result = {'Result':'Fail','Reason':"Can't connecting to Emulab of KREONET Emulab"}
            print result
            return result
        else:
            loginurl = 'https://www.emulab.kreonet.net/login.php3'
            data = 'uid=%s&password=%s&login=Login' % (id, pw)
            ssong = self.opener.open(loginurl, data).read()
            if ssong.find('Logged in') is not -1:
                where, tempstring = ssong.find('https://www.emulab.kreonet.net/showuser.php3?user=') + len('https://www.emulab.kreonet.net/showuser.php3?user='), ''
                while True:
                    if ssong[where] == "'":
                        break
                    else:
                        tempstring += ssong[where]
                        where += 1
                userid = tempstring
                where, tempstring = ssong.find('<td>Username:</td>') + len('<td>Username:</td>'), ''
                while True:
                    if ssong[where] == '(':
                        break
                    else:
                        tempstring += ssong[where]
                        where+=1
                tempstring = tempstring.replace('<td>','').strip()
                username = tempstring
                infodic['result'], infodic['usernmae'],infodic['userid'] = 'Success', username, userid
                return infodic
            else:
                result = {'Result':'Fail',"Reason":"Log-in fail"}
                print result
                return result

    def __logout(self, infodic):
        url = 'https://www.emulab.kreonet.net/logout.php3?user=%s' % infodic['userid']
        if str(self.opener.open(url).read()).find('https://www.emulab.kreonet.net/logon.gif') is not -1:
            result = {'Result' : 'Success', 'reason' : 'Logout Success'}
        else:
            result = {'Result' : 'Fail', 'reason' : 'Logout Fail'}
        return result

    def Analyze(self, id, pw):
        if self.proj is None or self.reboot is None or self.report is None or self.filedump is None or \
        self.registrydump is None or self.trafficdump is None or  self.filepath is None:
            print 'Please set options through Analysis_setting func'
            sys.exit(1)
        login_result = self.__login(id, pw)
        if login_result['result'] is not 'Success':
            print 'Login Fail: It is predicted that ID or Password is incorrect.'
            sys.exit(1)
        else:
            print 'Login Success'

        #Removing a mail logic because this logic is judged not necessary
        """
        if self.report == 'Yes' or self.reboot == 'yes':
            Mailaddress = self.__MailParsing(id, pw)
        else:
            pass
        """

        session = hashlib.md5(str(id)+str(pw)+str(time.time())).hexdigest()[:12]
        print 'Session : %s' % session

        # Creating folder that name like "SessionList"
        # Log fil in SessionList folder will includes information like time, session name, etc based on json format.
        # checking a directory that whether exists or not
        if not os.path.exists('./Session_List'):
            os.mkdir('./Session_List')
        # End

        # Session data generating based on json format
        self.sessiondata['Session'], self.sessiondata['Progress_rate'], self.sessiondata['Progress_step'], self.sessiondata['Made_time'] = session, '5%', 'A node creation for analysis begins.', str(datetime.datetime.now())
        #self.sessiondata['UserInfo'] = dict({'UserMail':Mailaddress, "Userid" : hashlib.md5(id).hexdigest(), 'Password': hashlib.md5(pw).hexdigest()})
        self.sessiondata['UserInfo'] = dict({"Userid" : hashlib.md5(id).hexdigest(), 'Password': hashlib.md5(pw).hexdigest()})
        self.sessiondata['Options'] = dict({'Project':self.proj, 'reboot':self.reboot, 'report':self.reboot,
                                           'filedump':self.filedump, 'registrydump':self.registrydump,
                                           'trafficdump':self.trafficdump, 'filepath':self.filepath})
        json_sessiondata = json.dumps(self.sessiondata)
        # End

        # File writing
        with open('./Session_List/%s.json' % session,'w') as fp:
            fp.write(json_sessiondata)
        # End

        # Making the entire session list file
        Sessioninfo = dict()
        with open('./Session_List/Entire_Session.json', 'a+') as fp:
            Sessioninfo['%s' % session] = dict({'Project':self.proj, 'Made_time':self.sessiondata['Made_time'], 'Analysis_file':self.filepath})
            json_sessioninfo = json.dumps(Sessioninfo)
            fp.seek(0, 2)
            fp.write('\n')
            fp.write(json_sessioninfo)
        # End

        # Approach Changing
        # Single Class module method --> Multiple script files method

        # Fork() --> __NodeCreating() // This logic is unable in Windows.
        # command to distribute processing.
        # If this script is being executed in Linux environment, it will use "nohup" command

        EncryptedID, EncryptedPW = self.EncryptionAES(id), self.EncryptionAES(pw)

        if platform.system() == 'Windows':
            # Subporcess (start) for Windows Env
            CREATE_NO_WINDOW = 0x08000000
            with open(os.devnull, 'w') as tempf:
                subprocess.call('start /MIN /REALTIME python ./SingleLib_analysis.py %s %s %s' % (session, EncryptedID, EncryptedPW), shell=True, stderr=tempf, stdout=tempf, creationflags=CREATE_NO_WINDOW)
                #subprocess.Popen('start pythonw ./SingleLib_analysis.pyw', shell=True, stdout=tempf, stderr=tempf, creationflags=CREATE_NO_WINDOW)

            # For windows Env, End
        elif platform.system() == 'Linux':
            # Subporcess (nohup) for Linux Env
            # A logic In the below is made for Linux env.
            subprocess.call('nohup python SingleLib_analysis.py %s %s %s & > /dev/null &' % (session, EncryptedID, EncryptedPW), shell=True)

            # For Linux Env, End
        else:
            print 'This platform : %s is unable to execute this library script. \n Only Linux and Windows platform are able.' % str(platform.system())

        return session

    def Progress(self, sessionid):
        if sessionid is None and sessionid is '':
            print 'Session id is incorrect'
            sys.exit(1)
        else:
            with open('./Session_List/%s.json' % sessionid, 'r+') as fp:
                content = json.loads(fp.read())
                progress_step = content['Progress_step']
                progress_rate = content['Progress_rate']
                print 'Progress step : %s' % str(progress_step)
                print 'Progress rate : %s' % str(progress_rate)

    def Allinfo(self, sessionid):
        if sessionid is None and sessionid is '':
            print 'Session id is incorrect'
            sys.exit(1)
        else:
            with open('./Session_List/%s.json' % sessionid, 'r+') as fp:
                content = json.loads(fp.read())
                del content['UserInfo']
                keys = content.keys()
                for i in keys:
                    print '%s : %s' % (i, content[i])

    def SessionList(self):
        if not os.path.exists('./Session_List'):
            print 'For this function, The analysis must be progressed more than a one time.'
            sys.exit(1)
        if not os.path.exists('./Session_List/Entire_Session.json'):
            print 'For this function, The analysis must be progressed more than a one time.'
            sys.exit(1)
        with open('./Session_List/Entire_Session.json') as fp:
            content = fp.readlines()
            for i in content:
                json_content = json.loads(i)
                keys = json_content.keys()
                print 'All Session information'
                for j in keys:
                    print 'Session :',
                    print '%s : %s' % (j, json_content[j])

    """
    def __MailParsing(self, id, pw):

        # Removing a mail logic because this logic is judged not necessary.
        # Mail address parsing logic
        loginurl = 'https://www.emulab.kreonet.net/login.php3'
        data = 'uid=%s&password=%s&login=Login' % (id, pw)
        ssong = self.opener.open(loginurl, data).read()
        if ssong.find('Logged in') is not -1:
            where, tempstring = ssong.find('https://www.emulab.kreonet.net/showuser.php3?user=') + len('https://www.emulab.kreonet.net/showuser.php3?user='), ''
            while True:
                if ssong[where] == "'":
                    break
                else:
                    tempstring += ssong[where]
                    where += 1
            userid = tempstring
        url = 'https://www.emulab.kreonet.net/moduserinfo.php3?user=10003'
        mail_address = BeautifulSoup.BeautifulSoup(self.opener.open(url).read()).findAll('input', attrs={'type':'hidden','name':'formfields[usr_email]'})[0]['value']
        # Parsing logic end

        # Confirm a mail format and data logic

        if str(mail_address).find('@') is -1:
            print "Couldn't find information about account's mail address in KREONET Emulab.\n"
            try:
                mail_address = raw_input("Please Enter a your mail address manually.")
            except:
                print 'Exit'

        # End
        return mail_address
    """

    '''
    def __Analyzing(self, session):
        for i in range(5000):
            print session
            session = str(session) + str(i)
            with open('./Session_List/%s' %session , 'w') as fp:
                fp.write('test')
            time.sleep(1)

        # Mail address parsing logic must be needed because of a report option.
        print 'asd'
    '''

def main():
    ssong = SingleLib()
    #ssong.SessionList()
    ssong.Analysis_setting(proj='SingleLib', reboot='No', report='Yes', filedump='Yes', registrydump='Yes', trafficdump='Yes', filepath='./Files_for_Uploading/Executiontest/test.exe')
    #ssong.Analysis_setting(proj='SingleLib', reboot='Yes', report='Yes', filedump='Yes', registrydump='Yes', trafficdump='No', filepath='./Files_for_Uploading/Executiontest/test.exe')
    ssong.Analyze('mhlee','hnu7667')
    ssong.Allinfo('b8ea8d87a1f8')
    #ssong.Progress('b8ea8d87a1f8')

if __name__ == '__main__':
    main()

