# -*- coding:utf-8 -*-

try:
    import os, sys, time, base64, subprocess, datetime, platform
    import urllib, urllib2, cookielib, ssl
    import mechanize, BeautifulSoup
    import hashlib, json, inspect
    from Crypto.Cipher import AES
except:
    print 'Module Importing Fail'
    exit(1)

try:
    import pysftp
    import paramiko
except:
    print 'pass'
    # TODO : Adding the exception processing

cj = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
uid, session, = '', ''
mbrmark = 0

def Encryption(): #암호화 모듈
    global EncryptionAES
    global DecryptionAES
    BLOCK_SIZE = 32
    PADDING = '|'
    secret = 'XJjOXNHY2lya2lZZTdkVzE0RU54L0Fwc'
    cipher = AES.new(secret)

    pad = lambda s : s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
    EncryptionAES = lambda s : base64.b64encode(cipher.encrypt(pad(s)))
    DecryptionAES = lambda e : cipher.decrypt(base64.b64decode(e)).rstrip(PADDING)

def connect():
    url = 'https://www.emulab.kreonet.net'
    ssong = opener.open(url).read()
    if ssong.find('emulab.kreonet.net - Emulab - Network Emulation Testbed Home'):
        result = {'Result':'Success'}
    else:
        print 'Connecting with Emulab is fail'
        result = {'Result':'fail','Reason':'Connecting Fail'}
    return result

def login(id, pw):
    global uid
    url = 'https://www.emulab.kreonet.net/login.php3'
    if str(opener.open(url).read()).find('emulab.kreonet.net - Login') is not -1:
        data = 'uid=%s&password=%s&login=Login' % (id, pw)
        ssong = opener.open(url, data).read() # Need the exception #
        if ssong.find('Logged in') is not -1:
            print 'Login Success'
            where = ssong.find('https://www.emulab.kreonet.net/logout.php3?user=') + len('https://www.emulab.kreonet.net/logout.php3?user=')
            while True:
                if ssong[where] == "'":
                    break
                else:
                    uid += ssong[where]
                    where += 1
            result = {'Result':'Success','uid': uid}
        else:
            #print 'Login fail'
            result = {'Result':'fail','Reason':'Login Fail'}
        return result


def NodeCreating(id, pw):
    global session, subject
    result = connect()
    if result['Result'] is not 'fail':
        result = login(id, pw)
        if result['Result'] is not 'fail':
            # First, confirm a user's subject list on node creating page in Emulab and selecting and parsing the first subject.
            subject = Parsing_subject()

            # survey nodes that whether available or not
            available = AvailableNodes()

            # Make the content
            # TODO : I must check that whether a ns file is existed or not.
            content = Writing_nsfile(available)
            with open('./Session_List/%s.ns' % session, 'w') as fp:
                fp.write(content)
            # Checking part


            # Checking part end

            # transporting a nsfile to path under the group after making a nsfile.
            # A written nsfile will have to be deleted when a node has been created.
            remotepath = '/proj/%s/' % subject

            host, port= 'users.emulab.kreonet.net', 22
            # transporting
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None
            with pysftp.Connection(host=host, username=id, password=pw, port=22, cnopts=cnopts) as sftp:
                with sftp.cd('/proj/%s' % subject):
                    sftp.put('./Session_List/%s.ns' % session) #

                # making a node using recognizing forms, attributes in html so turning to mechanize module.i
                try:
                    browser = mechanize.Browser()
                    browser.set_cookiejar(cj)
                    browser.open('https://www.emulab.kreonet.net/beginexp.php').read()
                    browser.select_form(name='form1')
                    browser.form['formfields[exp_pid]'] = ['DStesting12',]
                    browser.form['formfields[exp_id]'] = '%s' % session # Usingnode Table 의 pid값을 따라감.
                    browser.form['formfields[exp_description]'] = '%s' % session # 동일
                    browser.form['formfields[exp_localnsfile]'] = '/proj/%s/%s.ns' % (subject, session)# 해당부분은 Integrity를 위해 hash값으로 파일을 만들고 홰당 파일을 업로드 하여야 함.
                    browser.form['formfields[exp_idleswap_timeout]'] = '2'
                    browser.form['formfields[exp_noidleswap_reason]'] = ''
                    browser.form['formfields[exp_autoswap_timeout]'] = '16' # End
                    ssong = browser.submit()
                except:
                    print 'Module making fail'
                    sys.exit(1)
                else:
                    with open('./Session_List/%s.json' % session, 'r+') as fp:
                        # reading and modifying the config file
                        content = json.loads(fp.read())
                        content['Progress_step'] = "A node for analysis in Emulab is being created."
                        content['Progress_rate'] = '10%'
                        content['Nodeinfo'] = '%s' % available
                        content = json.dumps(content)
                        fp.seek(0)
                        fp.truncate()
                        fp.seek(0)
                        fp.write(content)
                    return {'Result':'Success','Subject':subject}
        else:
            print result['Reason']
            sys.exit(1)
    else:
        print result['Reason']
        sys.exit(1)

def analyzing(id, pw, subject):
    global uid, analysis_command
    global session
    print 'Pointer in the analzing func'
    #TODO : This session var have to be deleted
    #session = '3b66c1ea05d3'
    errormsg = ''
    flag, sequence, threshold = 0, 0, 0
    time.sleep(10) # Waiting for loading the web page

    count = 0 # temp variable
    while True:
        try:
            # Confirming a node's status continuously
            while True:
                try:
                    url = 'https://www.emulab.kreonet.net/showexp.php3?pid=%s&eid=%s' % (subject, session)
                    ssong = opener.open(url).read()
                    print 'contents reading success (1)'
                except:
                    print 'Connecting to know the status of node is failed It will be re-tried'
                    sys.exit(1)
                else:
                    break
            # New codes are added to protect infinity loop happening
            if ssong.find("Could not map page arguments to 'experiment'") is not -1:
                raise Exception('Defined_Error_by_Ssong',"Maybe, this script couldn't find the node status page")
            else:
                soup = BeautifulSoup.BeautifulSoup(ssong).findAll('td')

            for i in range(0, len(soup)):
                if str(soup[i]).find('<td>up</td>') is not -1 or str(soup[i]).find('<td>down (BOOTING)</td>') is not -1:
                    #print str(soup[i])
                    sequence = i
                    break
                else:
                    #print 'Searching "td" element lists'
                    pass

            print 'sequence number : %s' % str(sequence)

            # if it couldn't find the sentence, what number do sequence variable have?
            # print 'A node status is predicted like down (RELOADING)'

            if str(soup[sequence]).find('<td>up</td>') is not -1:
                print 'Available resource is found :' + str(soup[sequence])
                ### Writing a content to the config file
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    # reading and modifying the config file
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'An Available node is activated'
                    content['Progress_rate'] = '15%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                    fp.close()
                    flag = 1
                    ### End
            if str(soup[sequence]).find('<td>down (BOOTING)</td>') is not -1:
                with open('./Session_List/%s.json' % session, 'r+') as fp:
                    # reading and modifying the config file
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'An Available node is being booted'
                    content['Progress_rate'] = '10%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                    fp.close()
                    # TODO : 위의 로직 수행하고 나서 멈춤 현상 발생 원인조사필요
                print 'A node is being created'
                print 'test(%s): %s ' % (str(count), str(soup[sequence])) # This sentence has to be removed
                count += 1  # This sentence has to be removed
            if flag == 1:
                break
            else:
                time.sleep(60)
                pass
        except:
            errormsg = sys.exc_info()
            print 'Exception has been happened'
            print errormsg
            #os.system('pause')
            if threshold > 10:
                if str(errormsg).find('Connection refused') is not -1:
                    print 'Connection refused'
                    threshold = 0
                else:
                    print errormsg
                    exit(1)
            else:
                threshold += 1
                time.sleep(5)
                pass

    while True:
        try:
            #Deleting a ns file that was made by nodecreating module.
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('users.emulab.kreonet.net', username=id, password=pw)
            print 'ssh success(1)' # temp
        except:
            error = sys.exc_info()
            print error
            print 'ssh error(1)' # temp
            time.sleep(10)
        else:
            break
    try:
        stdin, stdout, stderr = ssh.exec_command('rm /proj/%s/%s.ns' % (subject, session)) #마킹
    except:
        print 'Error happens in deleting a ns file'
    else:

        print 'rm ns success (1)' # temp
        pass

    # Util program related to analysis transport part start
    if os.path.exists('./Util'):
        if not os.path.isfile('./Util/SystemSherLock/systemsherlock.exe'):
            print "Couldn't find a SystemSherLock util program."
            sys.exit(1)
        elif not os.path.isfile('./Util/packetcapture/RawCap.exe'):
            print "Couldn't find a RawCap util program."
            sys.exit(1)
        else:
            pass
    else:
        print "Couldn't find a util directory"
        sys.exit(1)

    ## Checking a directory that whether exists or not into the remote node to transfer util programs
    while True:
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('users.emulab.kreonet.net', username=id, password=pw)
            print 'ssh success(2)' # temp
        except:
            print 'ssh error(2)' # temp
            time.sleep(10)
        else:
            break
    try:
        # Confirming a directory that whether exist or not
        stdin, stdout, stderr = ssh.exec_command('ls -al /proj/%s | grep Util' % subject)
        data = stdout.read()
        if str(data).strip() == '':
            stdin, stdout, stderr = ssh.exec_command('mkdir /proj/%s/Util' % subject)
            stdin, stdout, stderr = ssh.exec_command('ls -al /proj/%s | grep Util' % subject)
            data = stdout.read()
        # Directory confirm part end

            # Transferring util programs part
            host, port= 'users.emulab.kreonet.net', 22
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None
            with pysftp.Connection(host=host, username=id, password=pw, port=22, cnopts=cnopts) as sftp:
                with sftp.cd('/proj/%s/Util' % subject):
                    sftp.put('./Util/SystemSherLock/systemsherlock.exe')
                    sftp.put('./Util/packetcapture/RawCap.exe')
            # Transferring util programs part end
        else:
            pass
    except:
        with open('./Session_List/%s.json' % session , 'r+') as fp:
            # reading and modifying the config file
            content = json.loads(fp.read())
            content['Progress_step'] = 'An error has occurred in checking a file and transferring step. '
            content['Progress_rate'] = '17%'
            content = json.dumps(content)
            fp.seek(0)
            fp.truncate()
            fp.seek(0)
            fp.write(content)
        print 'Connecting to a node is fail'
        sys.exit(1)

    else:
        with open('./Session_List/%s.json' % session , 'r+') as fp:
            # reading and modifying the config file
            content = json.loads(fp.read())

            # Assign a node name to connect to a node(e.g : pc24)
            nodenumber = content['Nodeinfo']
            exist_file_path = content['Options']['filepath']
            print 'exist file path : %s' % str(exist_file_path)
            analysis_filename = os.path.basename(exist_file_path)
            # Assign end

            content['Progress_step'] = 'Transferring util programs for analysis has been succeeded.'
            content['Progress_rate'] = '20%'
            content = json.dumps(content)
            fp.seek(0)
            fp.truncate()
            fp.seek(0)
            fp.write(content)

    ## Checking part end
    # Util program related to analysis transport part end

    # Analyzing part start

        ## To transfer a file for analyzing, several assigning are needed. \n
        ## Part for transferring start.

    # KISTI's Emulab node has static ip address of A, B, C, class

    # TODO : It must be deleted
    host = 'users.emulab.kreonet.net'  # it must be changed to a node_ip var
    defaultpath = '/cygdrive/c/Users/Default/'
    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None
    node_ip = '203.250.172.'+str(nodenumber).replace('pc','')
    print 'node ip: %s' % node_ip

    # TODO : This code must be deleted
    #node_ip = '203.250.172.30'  # For testing

    file_trans_path = '/cygdrive/c/Users/Default/'
    # Variable set part end

    # The password for windows parsing part start
    winpw_threshold = 0
    while True:
        try:
            if threshold > 10:
                print 'Connecting with Emulab web page failed'
                sys.exit(1)
            else:
                try:
                    url = ' https://www.emulab.kreonet.net/moduserinfo.php3?user=%s' % uid
                    windows_pw = BeautifulSoup.BeautifulSoup(opener.open(url).read()).findAll('input',attrs={'name':'formfields[w_password1]'})[0]['value']
                except:
                    time.sleep(1)
                    pass
                else:
                    break
        except:
            time.sleep(5)
            winpw_threshold +=1
        else:
            pass
    # The password for windows parsing part end

    with pysftp.Connection(host=node_ip, username=id, password=windows_pw, port=22, cnopts=cnopts) as sftp: # Testversion
    #with pysftp.Connection(host=node_ip, username=id, password=pw, port=22, cnopts=cnopts) as sftp:
        with sftp.cd('%s' % defaultpath):
            sftp.put('%s' % exist_file_path)

        ## Part for transferring end
        ## Transferring part end

    with open('./Session_List/%s.json' % session , 'r+') as fp:
        content = json.loads(fp.read())
        # Assign set configuration value to variable
        filedump = content['Options']['filedump']
        regdump = content['Options']['registrydump']
        trafficdump = content['Options']['trafficdump']
        reboot = content['Options']['reboot']
        report = content['Options']['report']
        #mail = content['UserInfo']['UserMail']
        # Assign end

    if trafficdump == 'No':
        network_command = None
    else:
        network_command = 'cd %s; /proj/%s/Util/RawCap.exe -s 300 %s Captured_packet.pcap > /dev/null &' % (defaultpath, subject, node_ip)

        ## executing commands before executing a file for analysis
    if filedump == 'Yes' and regdump == 'Yes':
        analysis_command = 'cd %s; /proj/%s/Util/systemsherlock.exe -dump before.dat -regdirs HKEY_ROOT -dirs c:/' % (defaultpath, subject)
        analysis_command_after = 'cd %s; /proj/%s/Util/systemsherlock.exe -dump after.dat -regdirs HKEY_ROOT -dirs c:/' % (defaultpath, subject)
    if filedump == 'Yes' and regdump == 'No':
        analysis_command = 'cd %s; /proj/%s/Util/systemsherlock.exe -dump before.dat -dirs c:/' % (defaultpath, subject)
        analysis_command_after ='cd %s; /proj/%s/Util/systemsherlock.exe -dump after.dat -dirs c:/' % (defaultpath, subject)
    if filedump == 'No' and regdump == 'Yes':
        analysis_command = 'cd %s; /proj/%s/Util/systemsherlock.exe -dump before.dat -regdirs HKEY_ROOT' % (defaultpath, subject)
        analysis_command_after = 'cd %s; /proj/%s/Util/systemsherlock.exe -dump after.dat -regdirs HKEY_ROOT' % (defaultpath, subject)
    if filedump == 'No' and regdump == 'No':
        analysis_command = None
        analysis_command_after = None
        ## executing commands before executing a file for analysis part end

    print 'Analysis command initial :%s' % analysis_command_after

        ## initial dump part start
    try:
        if analysis_command == None:
            pass
        else:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('%s' % node_ip, username=id, password=windows_pw)
            try:
                stdin, stdout, stderr = ssh.exec_command('%s' % analysis_command)
                print analysis_command
            except:
                print 'Error happens in deleteing a ns file'
            else:
                pass
    except:
        print 'Initial dump processing error!'
        sys.exit(1)
    else:
        with open('./Session_List/%s.json' % session , 'r+') as fp:
            # reading and modifying the config file
            content = json.loads(fp.read())
            content['Progress_step'] = 'Initial dump processing succeed for analysis.'
            content['Progress_rate'] = '25%'
            content = json.dumps(content)
            fp.seek(0)
            fp.truncate()
            fp.seek(0)
            fp.write(content)
        ## I have to think that whether this system is needed to check the process status for protecting a duplication between processes because a paramiko doesn't wait until when a Systemsherlock process has been ended.
        while True:
            stdin, stdout, stderr = ssh.exec_command('ps')
            ssong = stdout.read()
            if str(ssong).find('systemsherlock') is not -1:
                time.sleep(10)
            else:
                break
        ## Initial dump part end


        ## An Analysis file execution part start
    try:
        execution_command = 'cd %s; ./%s' % (defaultpath, analysis_filename)
        print 'anaylsis command: %s' % str(analysis_filename)
        stdin, stdout, stderr = ssh.exec_command('%s' % execution_command)
        print 'execution command : %s' % str(execution_command)
        # TODO : Waiting code is needed to be controllable. (Default : 15) config based ? Instance variable based?
        time.sleep(3)
    except:
        print 'Executing a file for analysis is failed'
        sys.exit(1)
    else:
        with open('./Session_List/%s.json' % session , 'r+') as fp:
            # reading and modifying the config file
            content = json.loads(fp.read())
            content['Progress_step'] = 'Executing a file for analysis is succeeded'
            content['Progress_rate'] = '30%'
            content = json.dumps(content)
            fp.seek(0)
            fp.truncate()
            fp.seek(0)
            fp.write(content)
        ## An Analysis file execution part end

        ## Rebooting part start
    if reboot == "Yes":
        print 'Before rebooting'
        result = login(id, pw)
        if result['Result'] is not 'fail':
            pass
        else:
            print 'Login to a Emulab page fail'
            sys.exit(1)
        reboot_command = 'shutdown -r -f -t 00'
        url = 'https://www.emulab.kreonet.net/showexp.php3?pid=%s&eid=%s' % (subject, session)
        print url
        # For testing, session value must be changed
        result = ''
        try:
            stdin, stdout, stderr = ssh.exec_command('%s' % reboot_command)
            print 'After rebooting'
        except:
            time.sleep(60)
            print 'Exception in reboot'
            monitoringcount = 0
            while True:
                print 'This script in the loop'
                try:
                    ssong = opener.open(url).read()
                    #print ssong
                except:
                    # Access fail to a Emulab web page
                    time.sleep(10)
                else:
                    if ssong.find('<td>up</td>') is not -1:
                        result = 'Reboot Success'
                        print 'Result %s' % result
                        break # Reboot Success
                    elif ssong.find('<td>possibly down (BOOTING)</td>') is not -1:
                        result = 'MBR broken'
                        print result
                        break # Predicted that MBR or Bootloader is broken
                    elif monitoringcount >= 30:
                        result = 'Node reboot fail'
                        print result
                        break # Node reboot fail
                    else:
                        time.sleep(10)
                        monitoringcount += 1
        else:
            print 'Rebooting succeed, we will sleep for 5 minutes until a node has been booted.'
            time.sleep(300)
            while True:
                try:
                    ssong = opener.open(url).read()
                    #print ssong
                except:
                    # Access fail to a Emulab web page
                    time.sleep(10)
                else:
                    if ssong.find('<td>up</td>') is not -1:
                        result = 'Reboot Success'
                        print 'result2 %s' % result
                        break
                    elif ssong.find('<td>possibly down (BOOTING)</td>') is not -1:
                        result = 'MBR broken'
                        print result
                        break # Predicted that MBR or Bootloader is broken
                    elif ssong.find('<td>possibly down (TBFAILED)</td>') is not -1:
                        result = 'Reboot Success'
                        print result
                        break
                    else:
                        time.sleep(10)
                        pass

        if result == 'Node reboot fail':
            print 'Node reboot fail'
            with open('./Session_List/%s.json' % session , 'r+') as fp:
                # reading and modifying the config file
                content = json.loads(fp.read())
                content['Progress_step'] = 'Rebooting failed, Please try again or change options'
                content['Progress_rate'] = '35%'
                content = json.dumps(content)
                fp.seek(0)
                fp.truncate()
                fp.seek(0)
                fp.write(content)
            sys.exit(1)
        elif result == 'Reboot Success':
            print 'Reboot Success'
            with open('./Session_List/%s.json' % session , 'r+') as fp:
                # reading and modifying the config file
                content = json.loads(fp.read())
                content['Progress_step'] = 'Rebooting succeed'
                content['Progress_rate'] = '35%'
                content = json.dumps(content)
                fp.seek(0)
                fp.truncate()
                fp.seek(0)
                fp.write(content)
        elif result == 'MBR broken':
            print "Predicted that a node's status is possibly down"
            with open('./Session_List/%s.json' % session , 'r+') as fp:
                content = json.loads(fp.read())
                content['Progress_step'] = 'It is predicted MBR is broken.'
                content['Progress_rate'] = '35%'
                content = json.dumps(content)
                fp.seek(0)
                fp.truncate()
                fp.seek(0)
                fp.write(content)
            MBR_Extraction(id, pw, session, node_ip, subject, windows_pw)
    else:
        pass
        ## Rebooting part end


    print 'mbrmark : %s' % str(mbrmark)
    # This logic checks whether the logic extracting MBR has been conducted.
    if mbrmark != 1:
        # Must be modified
        print 'Rebooting Logic end'
        # Re-establishing the connecting
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('%s' % node_ip, username=id, password=windows_pw)
        except:
            error = sys.exc_info()
            print "Re-establishing fail"
            print error
            sys.exit(1)
        else:
            pass

        # Network packet capture part start
        if network_command == None:
            pass
        else:
            try:
                stdin, stdout, stderr = ssh.exec_command(network_command)
            except:
                print 'Packet Capture Fail'
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Packet capture is failed.'
                    content['Progress_rate'] = '38%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                sys.exit(1)
            else:
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Packet capture start'
                    content['Progress_rate'] = '38%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
        # Network packet capture part End

        print 'Analysis command test : %s' % str(analysis_command_after)
        print 'printing test'
        print 'Analysis command after : %s\n' % str(analysis_filename)
        print 'printing test'
        print 'analysis_command_after : %s' % str(analysis_command_after)
        print 'printing test'

        #Final dump part start
        if analysis_command_after is not None:
            print 'Analysis command after is not None'
            compare_command = 'cd %s; /proj/%s/Util/systemsherlock.exe -compare before.dat after.dat' % (defaultpath, subject)
            try:
                stdin, stdout, stderr = ssh.exec_command(analysis_command_after)
            except:
                error = sys.exc_info()
                print error
                print 'Final dump process is failed'
                with open('./Session_List/%s.json' % session, 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Final dump process is failed'
                    content['Progress_rate'] = '40%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                sys.exit(1)
            else:
                while True:
                    stdin, stdout, stderr = ssh.exec_command('ps')
                    ssong = stdout.read()
                    if str(ssong).find('systemsherlock') is not -1:
                        time.sleep(10)
                    else:
                        break
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Final dump has been finished'
                    content['Progress_rate'] = '50%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
        else:
            print 'Analysis command else string :%s' % analysis_command_after
            compare_command = None
        #Final dump part end


        # Dump compare part start
        if compare_command is not None:
            print 'compare command is not None'
            print defaultpath
            print compare_command
            try:
                stdin, stdout, stderr = ssh.exec_command(compare_command)
                compare_result = stdout.read()
                #print compare_result
            except:
                error = sys.exc_info()
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Extracting information has been failed because of error.'
                    content['Progress_rate'] = '65%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                    ## Add MBR Extraction Logic --> make the function ?
                print error
                sys.exit(1)
            else:
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'Extracting requested information is succeeded.'
                    content['Progress_rate'] = '60%'
                    content['Analysis_result'] = compare_result
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
                pass
        else:
            pass
        # Dump compare part eend

        # Status checking part whether capturing is being worked or not\
        if network_command == None:
            pass
        else:
            try:
                while True:
                    stdin, stdout, stderr = ssh.exec_command('ps')
                    ssong = stdout.read()
                    if str(ssong).find('RawCap') is not -1:
                        time.sleep(10)
                    else:
                        break
            except:
                print 'Network status checking error'
                sys.exit(1)
            else:
                if os.path.exists('./Captured_packet'):
                    pass
                else:
                    os.mkdir('./Captured_packet')
                stdin, stdout, stderr = ssh.exec_command('cd %s; cat Captured_packet.pcap' % defaultpath)
                ssong = stdout.read()
                with open('./Captured_packet/%s_result.pcap' % session, 'wb') as fp:
                    fp.write(ssong)
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    content = json.loads(fp.read())
                    content['Progress_step'] = 'The captured network packet file has been downloaded.'
                    content['Progress_rate'] = '65%'
                    content['Analyzed_Packet_path'] = './Captured_packet/%s_result.pcap' % session
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)

        # Status checking part that whether capturing is being worked or not end

        """
        # Reporting through the mail part start

        # This logic is predicted that can be deleted # TODO : remove the mail logic
        with open('./Session_List/%s.json' % session , 'r+') as fp:
            content = json.loads(fp.read())
            report = content['report']
            if report == 'Yes':
                mailaddress = content['UserInfo']['UserMail']
            else:
                pass

        #Reporting through the mail part end
        """

        print 'Before closing the ssh connection'
        #Terminate()# ssong
        ssh.close()
        # Analyzing part End

def Terminate(id, pw, subject, session):
    result = login(id, pw)
    if result['Result'] is not 'fail':
        pass
    else:
        print 'Login to a Emulab page fail'
        sys.exit(1)

    url = 'https://www.emulab.kreonet.net/showexp.php3?pid=%s&eid=%s' % (subject, session)
    ssong = opener.open(url).read()
    where, expnumber = str(ssong).find("<a href='endexp.php3?experiment=") + len("<a href='endexp.php3?experiment="), ''
    while True:
            if ssong[where] == "'":
                    break
            else:
                    expnumber += ssong[where]
                    where += 1
    url = 'https://www.emulab.kreonet.net/endexp.php3?experiment=%s' % expnumber
    data = 'confirmed=Confirm'
    ssong = opener.open(url, data).read()
    if str(ssong).find('Terminate') is not -1:
        print 'Terminating Succeed'
        with open('./Session_List/%s.json' % session, 'r+') as fp:
            content = json.loads(fp.read())
            content['Progress_step'] = 'All process for analysis have been completed'
            content['Progress_rate'] = '100%'
            content = json.dumps(content)
            fp.seek(0)
            fp.truncate()
            fp.seek(0)
            fp.write(content)
    else:
        print 'Terminating Fail'

    print 'All processes are done'
    mbrmark = 1

def MBR_Extraction(id, pw, session, nodeip, subject, windows_passwd):
    with open('./Session_List/%s.json' % session , 'r+') as fp:
        content = json.loads(fp.read())
        content['Progress_step'] = 'Entering the MBR_Extraction func is succeeded'
        content['Progress_rate'] = '80%'
        nodepc_number = content['Nodeinfo']
        content = json.dumps(content)
        fp.seek(0)
        fp.truncate()
        fp.seek(0)
        fp.write(content)

    # The logic is needed to check the ops server status
    while True:
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('users.emulab.kreonet.net', username=id, password=pw)
        except:
            error = sys.exc_info()
            print error
            print 'Connecting error to ops server through ssh'
            time.sleep(5)
        else:
            break
    # The logic is needed to check the ops server status

    ping_command = 'ping %s -n 3' % nodeip
    admin_mode_command = '/usr/testbed/bin/node_admin on %s' % nodepc_number
    temporary_flag = 0
    try:
        stdin, stdout, stderr = ssh.exec_command(admin_mode_command)
        compare_result = stdout.read()
        print 'compare result:%s' % compare_result
        if str(compare_result).find('reboot (%s): Successful!' % nodeip) is not -1 or str(compare_result).find('%s now rebooting' % nodeip) is not -1:
            print 'Setting a node to admin mode'
        elif str(compare_result).find('Powercycle failed') is not -1:
            print'PowerCycle failed so we will wait more 5 minutes'
            time.sleep(300)
            stdin, stdout, stderr = ssh.exec_command(admin_mode_command)
            compare_result = stdout.read()
            print compare_result
        else:
            print 'Transforming to admin mode is failed'
            temporary_flag = 1
            print compare_result
            #sys.exit(1)
    except:
        print 'Transforming to admin mode is failed'
        #sys.exit(1)
    else:
        ssh.close()
        count = 1
        while True:
            try:
                ping_result = subprocess.check_output(ping_command, shell=True)
                print 'ping result: %s' % ping_result
                if str(ping_result).find('TTL') is not -1:
                    print 'Admin mode is activated.'
                    break
                else:
                    time.sleep(3)
            except subprocess.CalledProcessError:
                if count % 100 == 0:
                    try:
                        ssh = paramiko.SSHClient()
                        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                        ssh.connect('users.emulab.kreonet.net', username=id, password=pw)
                        stdin, stdout, stderr = ssh.exec_command(admin_mode_command)
                        compare_result = stdout.read()
                        if str(compare_result).find('reboot (%s): Successful!' % nodeip) is not -1 or str(compare_result).find('%s now rebooting' % nodeip) is not -1:
                            print 'Setting a node to admin mode'
                        elif str(compare_result).find('Powercycle failed') is not -1:
                            print'PowerCycle failed'
                    except:
                        print 'Re-connecting to ops server is fail'
                        time.sleep(3)
                print 'Checking the node status - %d' % count


                # TODO: if count % 300 == 0 then this process must be canceled and inform user that is impossible to analyze currently.

                count += 1
                if temporary_flag == 1:
                    print 'Temporary flag is 1'
                    print compare_result # This print is for tracking the logic.
                time.sleep(5)
        while True:
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect('%s' % nodeip, username=id, password=pw)
            except:
                time.sleep(3)
                pass
            else:
                break

        # Checking whether the directory exist or not

        if os.path.exists('./MBR_Image') is not True:
            os.mkdir('./MBR_Image')

        if os.path.exists('./MBR_Image/Native') is not True:
            os.mkdir('./MBR_Image/Native')

        if os.path.exists('./MBR_Image/Dumped') is not True:
            os.mkdir('./MBR_Image/Dumped')

        # End

        dumpcommand = "sudo dd if=/dev/mfid0 of=/proj/%s/%s.img bs=1b count=1" % (subject, session)
        stdin, stdout, stderr = ssh.exec_command(dumpcommand)
        dump_read_command= "cat /proj/%s/%s.img" % (subject, session)
        stdin, stdout, stderr = ssh.exec_command(dump_read_command)
        content = stdout.read()
        with open('./MBR_Image/Dumped/%s.img' % session, 'wb') as fp:
            fp.write(content)

    #Compare logic adding
    # admin mode on -> extracting -> compare -> admin mode off -> terminating

    disassemble_command, disassembled_content = 'ndisasm.exe -b 16 -o 7c00h -a -s 7c3eh', None

    # This logic is for that whether the file exist or not
    if os.path.exists('./Util/nasm') is not True:
        print "Coudln't find the module for the disassembler"
        Terminate(id, pw, subject, session)
        sys.exit(1)
    # End

    # Extracting the disassembled content
    # marking
    disassembled_content = subprocess.check_output('./Util/nasm/%s ./MBR_Image/Dumped/%s.img' % (disassemble_command, session))
    if disassembled_content is not None:
        if os.path.exists('./MBR_Image/Disassembled') is not True:
            os.mkdir('./MBR_Image/Disassembled')
        else:
            pass

    with open('./MBR_Image/Disassembled/%s.txt' % session, 'w+') as fp:
        fp.write('Disassembled contents\n')
        fp.write(disassembled_content)

    with open('./Session_List/%s.json' % session , 'r+') as fp:
        current_dir = os.getcwd()
        content = json.loads(fp.read())
        content['Progress_step'] = 'Disassembling the extracted image is done'
        content['Progress_rate'] = '95%'
        content['Extracted disk img file path'] = '%s/MBR_Image/Dumped/%s.img' % (current_dir, session)
        content['Disassembled img file path'] = '%s/MBR_Image/Disassembled/%s.txt' % (current_dir, session)
        content = json.dumps(content)
        fp.seek(0)
        fp.truncate()
        fp.seek(0)
        fp.write(content)
    # End
    #os.system('pause')

    #print 'Now it is in pause status please find me through a "marking" keyword' # marking
    Terminate(id, pw, subject, session)

def AvailableNodes():
    with open('./Session_List/%s.json' % session , 'r+') as fp:
        # reading and modifying the config file
        content = json.loads(fp.read())
        content['Progress_step'] = 'Confirming an available node'
        content['Progress_rate'] = '7%'
        content = json.dumps(content)
        fp.seek(0)
        fp.truncate()
        fp.seek(0)
        fp.write(content)

    while True:
        url = 'https://www.emulab.kreonet.net/shownodetype.php3?node_type=dellR710'
        soup = BeautifulSoup.BeautifulSoup(opener.open(url).read()).findAll('nobr')
        statuslist, numberlist = list(), list()
        for pc in soup:
            where, tempstring = str(pc).find('alt="') + len('alt="'), ''
            while True:
                if str(pc)[where] == '"':
                    break
                else:
                    tempstring += str(pc)[where]
                    where += 1
            statuslist.append(tempstring)

            where, tempstring = str(pc).find('&nbsp;') + len('&nbsp;'), ''
            while True:
                if str(pc)[where] == '<':
                    break
                else:
                    tempstring += str(pc)[where]
                    where += 1
            numberlist.append(tempstring)

        if len(statuslist) == len(numberlist):
            try:
                index = statuslist.index('free')
                available_node = numberlist[index]
            except ValueError: # Index func in list class has occurred the error if contents as the index argument is not existed.
                print 'Not found'
                time.sleep(15)
                with open('./Session_List/%s.json' % session , 'r+') as fp:
                    # reading and modifying the config file
                    content = json.loads(fp.read())
                    content['Progress_step'] = "An available node is empty so persistently monitoring a resource pool to make an experimental node."
                    content['Progress_rate'] = '7%'
                    content = json.dumps(content)
                    fp.seek(0)
                    fp.truncate()
                    fp.seek(0)
                    fp.write(content)
            else:
                error = sys.exc_info()
                print error
                break
    return available_node


def Parsing_subject():
    url = 'https://www.emulab.kreonet.net/beginexp.php'
    ssong = str(BeautifulSoup.BeautifulSoup(opener.open(url).read()).findAll('select', attrs={'name':'formfields[exp_pid]'}))
    optionlist, where, tempstring = list(), str(ssong).find('option value="') + len('option value="'), ''

    while True:
        if ssong[where] == '"':
            where += 1
            ssong = str(ssong)[where:]
            where = ssong.find('option value="') + len('option value="')
            if str(ssong).find('option value="') is -1:
                optionlist.append(tempstring)
                break
            else:
                if tempstring.strip() == '':
                    pass
                else:
                    optionlist.append(tempstring)
                    tempstring = ''
        else:
            tempstring += ssong[where]
            where += 1

    if optionlist is None:
        print "Couldn't find the subject list. Please make a subject." # or Raise
        sys.exit(1)
    else:
        return str(optionlist[0])

def Writing_nsfile(nodenumber):
    content = """
#generated by Netbuild 1.03
set ns [new Simulator]
source tb_compat.tcl

set node2 [$ns node]
tb-set-node-os $node2 Windows_seven
tb-fix-node $node2 %s


$ns rtproto Static
$ns run
#netbuild-generated ns file ends.""" % nodenumber

    return content

def main():
    global session
    Encryption()
    session, id, pw = sys.argv[1], sys.argv[2], sys.argv[3]
    id, pw = DecryptionAES(str(id)), DecryptionAES(str(pw))

    #id, pw = 'me0dQSZMUChu1cGgqSoXHWd7US0lrxa7uXnBBdjL2wA=', 'Nv3+oZ6nVhpRU7sqFhMriWd7US0lrxa7uXnBBdjL2wA='

    #session ='7c501cc3599d'
    # ID , PW confirm based on hash func
    with open('./Session_List/%s.json' % session , 'r') as fp:
        content = json.loads(fp.read())
        if content['UserInfo']['Userid'] == hashlib.md5(id).hexdigest():
            pass
        else:
            print 'ID is incorrect with saved ID in config.'
            sys.exit(1)
        if content['UserInfo']['Password'] == hashlib.md5(pw).hexdigest():
            pass
        else:
            print 'Password is incorrect with saved Password in config.'
            sys.exit(1)


    try:
        result = NodeCreating(id, pw)
        print result
        if result['Result'] == 'Success':
            analyzing(id, pw, str(result['Subject']))
        else:
            print 'Creating a node is fail'
    except:
        errormsg = sys.exc_info()
        os.system('pause')
        print errormsg

    else:
        Terminate(id, pw, str(result['Subject']), session)

    os.system('pause')

    # confirm a id, pw value that whether equal with saved hash data or not.

main()



'''
compare result:reboot (pc11): Attempting to reboot ...
*** node_reboot-reboot_node: pc11 appears dead; will power cycle.
Port 7, change to outletReboot: No answer from device
Outlet #7 control failed.
Control of pc11 failed.
*** ERROR: node_reboot-reboot: Powercycle failed for one or more of pc11
reboot: Done. There were 1 failures.
*** node_admin:
    WARNING: Could not reboot some of:  pc11!
   pc11
'''