# -*- coding:utf-8 -*-
__Developer__ = 'Gi-Beom Song'
__Contact__ = 'thdrlqjasla@gmail.com'
__Version__ = '1.0V'

try:
    import os, sys, time, base64
    import urllib, urllib2, cookielib, requests
    from Crypto.Cipher import AES
    import inspect
except:
    try:
        sys.path.insert(0, os.getcwd())
        import os, sys, time, base64
        import urllib, urllib2, cookielib, requests
        from Crypto.Cipher import AES
        import inspect
    except:
        importlfag = False
        pass
    if importlfag == False:
        print 'Error:We must need modules that are "os, sys, time, base64, urllib, urllib2, cookielib, inspect, PyCrypto, requests" Please install these.'
    else:
        pass
    
    # An example command for setting requests module : c:\Python27\Scripts\pip install requests (Windows_Version)
    # An example command for setting PyCrypto : easy_install http://www.voidspace.org.uk/python/pycrypto-2.6.1/pycrypto-2.6.1.win32-py2.7.exe
    
    exit(1)
else:
    pass

try:
    global cj, opener, url
    cj = cookielib.CookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
    url = 'http://hpsc2.hannam.ac.kr/~ssong/MASE/web/Interface.php'
except:
    print 'Error:Objects create failed.'
    exit(1)


def connecting():
    try:
        ConnectingConfrim = opener.open(url).read()
    except:
        return {'Result':'Fail'}
    else:
        return {'Result':'Success'}

    # must try to confirm the connection status of server.

def Session(id,pw):
    if id is None or pw is None:
        return 'Error:Please insert the your account information'
        exit(1)
    Connect = connecting()
    if Connect['Result'] is 'Fail':
        return "Error:Currently, can't connect to the MASE Server.\nPlease contact to us."
        exit(1)
    else:
        plaintext_id, plaintext_pw = str(id), str(pw)
        encryptext_id, encryptext_pw = CommonEncryption(plaintext_id), CommonEncryption(plaintext_pw)
        data = 'Request=Session&ID=%s&PW=%s' % (base64.encodestring(encryptext_id), base64.encodestring(encryptext_pw))
        ssong = opener.open(url, data).read().strip()
        if ssong == 'Wrong request':
            return 'Error:Please confirm the your account'
            exit(1)
        else:
            if len(ssong) is not 32:
                split = len(ssong) - 32
                ssong = ssong[split:len(ssong)]
            else:
                pass
            return ssong
    # must have to confirm the authentication using id and pw

def Analyze(session, proj, reboot, report, filedump, registrydump, trafficdump, uploaded_filepath):
    if session is None:
        print 'Error:session information is null.\n please insert the session data'
        exit(1)

    if filedump == 'No' and registrydump == 'No' and trafficdump == 'No':
        print 'Analysis options must be selected more than a one'
        exit(1)
    # A logic of bottom checks the whether a file and extract the name and extension of a file.
    if os.path.isfile(uploaded_filepath): # must have to check whether is file or nor.
        fp_exetension = os.path.splitext(os.path.basename(uploaded_filepath))
        fp_name = fp_exetension[0]+fp_exetension[1]
        fp_exetension = fp_exetension[1].lower()

        if fp_exetension == '.exe' or fp_exetension == '.exec': # must have to check the file's extension.
            pass
        else:
            print 'Error:We only support a file extension of "*.exe" or "*.exec" format and a file'+"'s extension must be written behind the filename which you wanna upload."
            exit(1) # Checking logic end.
    else:
        print 'Error:Only an execution file is possible to upload.'
        exit(1) # File checking logic end.

    # Variable's value checking logic
    frame = inspect.getargvalues(inspect.currentframe())
    for j in range(2, 7):
        if frame[3][frame[0][j]] is not 'Yes' and frame[3][frame[0][j]] is not 'No':
            print 'Please give a "%s" argument the value which is only "Yes" or "No".' % frame[0][j]
            exit(1)
        else:
            pass
    # End

    Connect = connecting() # Always must check the connection status between MASE server.
    if Connect['Result'] is 'Fail':
        return "Currently, can't connect to the MASE Server.\nPlease contact to us."
        exit(1)
    else:
        filearg = {'Analysisfile':open(uploaded_filepath,'rb')}
        data = {'Request':'Analyze','Session':session,'proj':proj,'reboot':reboot,'report':report,'filedump':filedump,'registrydump':registrydump,'trafficdump':trafficdump} # The logic that variables assign is end.

        AnalysisRequest = requests.post(url, files=filearg, data=data).text
        return AnalysisRequest

def Progress(session):
    Connect = connecting()
    if Connect['Result'] is 'Fail':
        return "Error:Currently, can't connect to the our system.\nPlease contact to us."
        exit(1)
    else:
        data = 'Request=%s&Session=%s' % ('Status',session)
        AnalysisProgress = opener.open(url, data).read()
        return AnalysisProgress

def Sessionlist(id, pw):
    if id is None or pw is None:
        return 'Error:Please insert the your account information'
        exit(1)
    else:
        Connect = connecting()
        if Connect['Result'] is 'Fail':
            return "Error:Currently, can't connect to the our system.\nPlease contact to us."
            exit(1)
        else:
            plaintext_id, plaintext_pw = str(id), str(pw)
            encryptext_id, encryptext_pw = CommonEncryption(plaintext_id), CommonEncryption(plaintext_pw)
            data = 'Request=Sessionlist&ID=%s&PW=%s' % (base64.encodestring(encryptext_id), base64.encodestring(encryptext_pw))
            list_Session = opener.open(url, data).read().strip()
            if list_Session is None:
                list_Session = 'Null'
                return list_Session
            else:
                listed_session = list()
                split_test = str(list_Session).split('\n')[1:len(str(list_Session).split('\n'))] # Can't predict the value of 0 of array
                for i in split_test:
                    listed_session.append(i)
                return listed_session

def ResultDownload(session, path=None):
    Connect = connecting() # Inquire the connection status
    if Connect['Result'] is 'Fail':
        return "Error:Currently, can't connect to the our system.\nPlease contact to us."
        exit(1)

    if path is None: # Check the parameter
        path = '.'
        pathdefaultflag = 1
    else:
	pathdefaultflag = 0 
        pass

    if os.path.isdir(path) is not True: # Check the directory available.
        print "Please don't include a file name at the path and only write the directory path. \n Example: c:/users/"
        exit(1)
    else:
        pass

    data = 'Request=Download&Session=%s' % session # The http protocol based data generation.
    asking = opener.open(url, data).read().strip() # Access to server which provides interface.
    asking = asking[str(asking).find('{'):len(asking)] # Parsing available contents
    if asking == '{This project has not been analyzed yet.}':
        asking = 'This project has not been analyzed yet.'
        return asking
    if asking == '{Resultpath:None}':
        asking = 'Not exists'
    else:
        # A string split logic for a convenient use of user
        where, file_reg_result, packet_analysis_result = str(asking).find('{Resultpath:') + len('{Resultpath:'), '', '' #Assign variables for an algorithm.
        while True:
            if str(asking)[where] is ',':
                break
            else:
                file_reg_result += asking[where]
                where += 1
        where = str(asking).find('Pcappath:') + len('Pcappath:')
        while True:
            if str(asking)[where] is '}':
                break
            else:
                packet_analysis_result += asking[where]
                where += 1
        # A string split logic part ended here.

        # Contents reading logic start
        resultdic = {"Analyzed file and registry result":"","Analyzed the network traffic result":""}
        if file_reg_result.strip() == "None":
            resultdic['Analyzed file and registry result'] = "It wasn't requested."
        else:
            try:
                print 'An analysis result file downloading...'
                filecontent = opener.open(file_reg_result).read().strip()
                # Must be changed to the request module.
            except:
                resultdic['Analyzed files and registry result'] = "%s" % file_reg_result
                if packet_analysis_result.strip() == "None":
                    resultdic['Analyzed the network traffic result'] = "It wasn't requested."
                else:
                    resultdic['Analyzed the network traffic result'] = "%s" % packet_analysis_result.strip()
                print "It couldn't download the file included analysis result, therefore directly provides its download path. \n %s" % resultdic
                return resultdic

            print 'An analyzed file and registry dump file is downloaded.'
            if pathdefaultflag == 1:
                fp = open(str(session)+'.txt', 'w')
            else:
                fp = open(path+str(session)+'.txt', 'w')
            fp.write(filecontent)
            fp.close()
            resultdic['Analyzed file and registry result'] = "Download Succeeded:%s/%s.txt" % (path, session)

        if packet_analysis_result.strip() == "None":
            resultdic['Analyzed the network traffic result'] = "It wasn't requested."
        else:
            if pathdefaultflag == 1:
                filename = str(session)+'.pcap'
            else:
                filename = path+str(session)+'.pcap'
            try:
                print 'Pcap file downloading...'
                packetcontent = urllib2.urlopen(packet_analysis_result)
                CHUNK = 8 * 1024
                with open(filename, 'wb') as f:
                    while True:
                        chunk = packetcontent.read(CHUNK)
                        if not chunk:
                            break
                        f.write(chunk)
            except:
                resultdic['Analyzed the network traffic result'] = "%s" % packet_analysis_result
                print "It couldn't download the file included captured analysis, therefore directly provides its download path."
                #print "It couldn't download the file included captured analysis, therefore directly provides its download path. \n %s" % resultdic
                return resultdic

            print 'An analyzed network traffic dump file is downloaded.'
            resultdic['Analyzed the network traffic result'] = "Download Succeeded:%s/%s.pcap" % (path, session)
        # Contents reading logic part ended here.
    return resultdic


def CommonEncryption(authstr):
    BLOCK_SIZE = 32
    PADDING = '{'
    #secret = '332SECRETabc1234'
    secret = '4TaShXQEBcwCXJLYYpq6rMHHe7Cp36ug'
    iv = 'HELLOWORLD123456'
    cipher = AES.new(secret, mode=AES.MODE_CBC, IV=iv)

    pad = lambda s : s + (BLOCK_SIZE - len(s) % BLOCK_SIZE) * PADDING
    EncryptionAES = lambda s : base64.b64encode(cipher.encrypt(pad(s)))
    DecryptionAES = lambda e : cipher.decrypt(base64.b64decode(e)).rstrip(PADDING)
    encoded = EncryptionAES(authstr)
    return encoded


    # must need to implements of a commonEncryption module

"""
if __name__ == '__main__':
    print 'Wrong execution'
    exit(1)
"""
